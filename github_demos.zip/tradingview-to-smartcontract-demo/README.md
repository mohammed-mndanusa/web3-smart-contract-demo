# TradingView to Smart Contract Execution Demo

This project simulates receiving alerts from TradingView and triggering a smart contract action.

## Features
- Webhook endpoint for TradingView alerts
- Simple action simulation (console or mock contract call)
- JSON payload handling

## Technologies
- Node.js
- Express.js
- Body-parser