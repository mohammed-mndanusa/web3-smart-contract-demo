# Web3 Smart Contract Interaction Demo

This is a simple demo project that shows how to connect a Node.js backend to an Ethereum smart contract using Ethers.js.

## Features
- Connect to Ethereum network (Infura or Alchemy)
- Interact with a deployed smart contract (read/write)
- Use .env for private keys and RPC setup

## Technologies
- Node.js
- Ethers.js
- Solidity (sample contract)