const { ethers } = require("ethers");
require("dotenv").config();

const provider = new ethers.JsonRpcProvider(process.env.RPC_URL);
const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
const contractAddress = "0xYourContractAddressHere";
const abi = [/* your contract ABI here */];

const contract = new ethers.Contract(contractAddress, abi, wallet);

async function readData() {
    const data = await contract.getValue();
    console.log("Contract Value:", data);
}

readData();